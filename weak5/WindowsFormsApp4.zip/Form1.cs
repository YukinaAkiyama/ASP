using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dataGridView1.Columns.Add("学生", "学生");
            dataGridView1.Columns.Add("C", "C程序");
            dataGridView1.Columns.Add("C++", "C++程序");
            dataGridView1.Columns.Add("Java", "Java程序");
            dataGridView1.Columns.Add("Python", "Python程序");
            dataGridView1.Columns.Add("C#", "C#程序设计");
            dataGridView1.Columns.Add("Rust", "Rust程序设计");
            dataGridView1.Columns.Add("平均分", "平均分");
            Random rand = new Random();
            for (int i = 0; i < 100; i++)
            {
                string s = "学生" + (i + 1);
                int c = rand.Next(1, 101);
                int cpp = rand.Next(1, 101);
                int java = rand.Next(1, 101);
                int python = rand.Next(1, 101);
                int csharp = rand.Next(1, 101);
                int rust = rand.Next(1, 101);
                dataGridView1.Rows.Add(s, c, cpp, java, python, csharp, rust);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 计算每一行的平均分
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                double sum = 0;
                for (int j = 1; j < dataGridView1.Columns.Count - 1; j++)
                {
                    sum += Convert.ToDouble(dataGridView1.Rows[i].Cells[j].Value);
                }
                double avg = sum / (dataGridView1.Columns.Count - 1);
                dataGridView1.Rows[i].Cells[dataGridView1.Columns.Count - 1].Value = avg.ToString("F2");
            }

            // 计算每一列的平均分
            for (int j = 1; j < dataGridView1.Columns.Count; j++)
            {
                double sum = 0;
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    sum += Convert.ToDouble(dataGridView1.Rows[i].Cells[j].Value);
                }
                double avg = sum / dataGridView1.Rows.Count;
                dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[j].Value = avg.ToString("F2");
            }
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[0].Value = "平均分";
        }
    }
}
