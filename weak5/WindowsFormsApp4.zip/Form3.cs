﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form3 : Form
    {
        private RichTextBox richTextBox = null;
        private TextBox file_path_textBox = null;
        private TextBox find_textBox = null;
        private TextBox replace_textBox = null;

        public Form3()
        {
            InitializeComponent();
            richTextBox = richTextBox1;
            file_path_textBox = textBox1;
            find_textBox = textBox2;
            replace_textBox = textBox3;
        }

        // 保存文件
        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox.SaveFile(file_path_textBox.Text, RichTextBoxStreamType.PlainText);

        }

        // 打开文件，并把文件显示到richtextbox中
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                file_path_textBox.Text = openFileDialog.FileName;
                richTextBox.LoadFile(openFileDialog.FileName, RichTextBoxStreamType.PlainText);
            }

        }

        // 根据find_textbox中的值查找文本并高亮
        private void button3_Click(object sender, EventArgs e)
        {
            string findText = find_textBox.Text;
            int index = 0;
            int lastIndex = richTextBox.Text.LastIndexOf(findText);
            while (index < lastIndex)
            {
                richTextBox.Find(findText, index, richTextBox.TextLength, RichTextBoxFinds.None);
                richTextBox.SelectionBackColor = Color.Yellow;
                index = richTextBox.Text.IndexOf(findText, index) + 1;
            }

        }

        // 全部替换
        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox.Text = richTextBox.Text.Replace(find_textBox.Text, replace_textBox.Text);

        }
    }
}
